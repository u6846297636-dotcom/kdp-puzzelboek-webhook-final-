
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    thema = data.get('thema')
    puzzeltype = data.get('puzzeltype')
    aantal = data.get('aantal')
    raster = data.get('raster')
    moeilijkheid = data.get('moeilijkheid')

    bestandsnaam = f"{thema}_{puzzeltype}_{aantal}_{raster}_{moeilijkheid}.pdf"
    return jsonify({"status": "success", "bestandsnaam": bestandsnaam})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
