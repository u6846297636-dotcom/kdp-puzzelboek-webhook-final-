
from flask import Flask, request, jsonify
import os

app = Flask(__name__)
UPLOAD_FOLDER = './uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/upload_epub', methods=['POST'])
def upload_epub():
    file = request.files.get('epub')
    if file and file.filename.endswith('.epub'):
        filepath = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(filepath)
        return jsonify({"status": "success", "message": f"Bestand '{file.filename}' ontvangen en opgeslagen."})
    return jsonify({"status": "error", "message": "Geen geldig EPUB-bestand ontvangen."})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
